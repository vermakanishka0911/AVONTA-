<?php
/**
 * Template Name: About (The Foundation)
 *
 * page-about.php
 *
 * Use this template for the About / Foundation page.
 */

get_header();
?>

<?php
while ( have_posts() ) :
  the_post();
  // If you prefer the editor content to appear, you can call the_content() below where appropriate.
endwhile;
?>

<main id="main-content" style="margin-top:110px;">

  <!-- HERO -->
  <section class="s-hero" aria-label="The Foundation: why AVONTAÉ was built">
    <?php if ( has_post_thumbnail() ) : ?>
      <?php the_post_thumbnail( 'avontae-hero', array( 'class' => 's-hero__image', 'alt' => the_title_attribute( array( 'echo' => false ) ) ) ); ?>
    <?php else : ?>
      <img class="s-hero__image"
        src="https://images.pexels.com/photos/20097234/pexels-photo-20097234.jpeg?auto=compress&cs=tinysrgb&w=1800&fit=crop"
        alt="A mother holding her newborn baby, their closeness quiet and complete"
        onerror="this.src='https://images.pexels.com/photos/19550894/pexels-photo-19550894.jpeg?auto=compress&cs=tinysrgb&w=1800&fit=crop'" />
    <?php endif; ?>
    <div class="s-hero__veil" aria-hidden="true"></div>
    <div class="s-hero__content">
      <h1 class="t-display">
        Before the cloth,<br>
        <em>the question.</em>
      </h1>
    </div>
  </section>

  <!-- THE ORIGIN -->
  <section class="s-origin reveal" aria-labelledby="origin-heading">
    <div class="s-origin__inner">
      <div>
        <img class="s-origin__photo"
          src="https://images.pexels.com/photos/19963841/pexels-photo-19963841.jpeg?auto=compress&cs=tinysrgb&w=900&fit=crop"
          alt="A newborn's tiny hands resting on a parent's chest, showing the scale and fragility of new life"
          onerror="this.src='https://images.pexels.com/photos/325690/pexels-photo-325690.jpeg?auto=compress&cs=tinysrgb&w=900&fit=crop'" />
        <p class="s-origin__aside-label" aria-hidden="true">Newborn. First stage. AVONTAÉ.</p>
      </div>
      <div>
        <p class="t-eyebrow" id="origin-heading">The Origin</p>
        <div class="u-rule" style="margin-top: 1.5rem; margin-bottom: 2.5rem;" aria-hidden="true"></div>
        <p class="t-body">
          AVONTAÉ begins with a single observation. The first year of life is not
          one state. It is a sequence of deeply distinct developmental stages,
          each with its own relationship to weight, warmth, movement, and skin.
          No luxury house has ever been organised around that reality.
        </p>
        <p class="t-body" style="margin-top: 1.5rem;">
          The conventional category organises itself by size. Weight ranges and
          height brackets become the architecture of a wardrobe. But a premature
          infant at 32 weeks corrected is not simply smaller than a full-term
          newborn. The skin is different. The thermoregulation is different.
          The access requirements for clinical care are different.
          Smallness is not the condition. Stage is the condition.
        </p>
        <p class="t-body" style="margin-top: 1.5rem;">
          This house is being built to answer that condition with the rigour
          of a French atelier. Nothing has been produced yet.
          The doctrine is what exists here. The doctrine is the foundation.
        </p>
      </div>
    </div>
  </section>

  <!-- IMAGE PAUSE: Stitch -->
  <div class="s-image-pause reveal" role="img"
    aria-label="Hand embroidery on linen fabric. A study in the time and care that craft requires.">
    <img
      src="https://images.pexels.com/photos/13631019/pexels-photo-13631019.jpeg?auto=compress&cs=tinysrgb&w=1800&fit=crop"
      alt="" aria-hidden="true"
      onerror="this.src='https://images.pexels.com/photos/7794365/pexels-photo-7794365.jpeg?auto=compress&cs=tinysrgb&w=1800&fit=crop'" />
    <p class="s-image-pause__caption" aria-hidden="true">Craft Study. Embroidery on Linen. AVONTAÉ.</p>
  </div>

  <!-- CRAFT CONVICTION -->
  <section class="s-standard reveal" aria-labelledby="craft-heading">
    <div class="s-standard__grid">
      <div>
        <p class="t-eyebrow" id="craft-heading">Craft Conviction</p>
        <div class="u-rule" style="margin-top: 2rem;" aria-hidden="true"></div>
      </div>
      <div>
        <ul class="s-standard__principles" role="list">
          <li>
            <span class="s-standard__index" aria-hidden="true">I</span>
            <span class="s-standard__text">
              <strong>Construction as Care</strong>
              How a garment is built determines how it behaves against the body.
              For skin that cannot yet fully regulate temperature, that bruises
              under unnecessary pressure, that reads every seam as sensation,
              construction is not an aesthetic decision. It is the first act
              of care the house places on a child.
            </span>
          </li>
          <li>
            <span class="s-standard__index" aria-hidden="true">II</span>
            <span class="s-standard__text">
              <strong>Material Before Silhouette</strong>
              The fibre is chosen first. Weave and weight follow. Silhouette is
              the final decision, shaped by what the material can support and
              what the stage demands of the body wearing it. No garment in
              this house begins from a sketch. It begins from a question
              about what touches the skin.
            </span>
          </li>
          <li>
            <span class="s-standard__index" aria-hidden="true">III</span>
            <span class="s-standard__text">
              <strong>Access as Architecture</strong>
              The NICU demands access to the body at any moment. Lines, monitors,
              temperature sensors. This is not a constraint on the design of
              a garment. It is a condition of it. A piece that cannot be
              opened without disturbing what keeps the child safe
              has no place in this house.
            </span>
          </li>
          <li>
            <span class="s-standard__index" aria-hidden="true">IV</span>
            <span class="s-standard__text">
              <strong>The Parent as the First Witness</strong>
              In the NICU, the parent stands beside their child for hours, days,
              weeks. They see every detail of what their child is wearing.
              What it says. Whether it belongs to the gravity of the moment.
              AVONTAÉ dresses for that witness as much as for the child.
              This is a house that understands what parents carry.
            </span>
          </li>
        </ul>
      </div>
    </div>
  </section>

  <!-- IMAGE PAUSE: Quote -->
  <div class="s-image-pause s-image-pause--text reveal" role="img"
    aria-label="A newborn held tenderly in both parents' hands. The earliest gesture of love.">
    <img
      src="https://images.pexels.com/photos/32447390/pexels-photo-32447390.jpeg?auto=compress&cs=tinysrgb&w=1800&fit=crop"
      alt="" aria-hidden="true"
      onerror="this.src='https://images.pexels.com/photos/9666398/pexels-photo-9666398.jpeg?auto=compress&cs=tinysrgb&w=1800&fit=crop'" />
    <div class="s-image-pause__overlay">
      <blockquote class="s-image-pause__quote">
        <p>The body at its most dependent<br>
          deserves the highest standard<br>
          <em>of everything that surrounds it.</em>
        </p>
      </blockquote>
    </div>
  </div>

  <!-- FORMATION: 3 Phases -->
  <section class="s-formation reveal" aria-labelledby="formation-heading">
    <div class="s-formation__inner">
      <p class="t-eyebrow" id="formation-heading">The Formation</p>
      <div class="u-rule" style="margin: 1.5rem 0 0;" aria-hidden="true"></div>
      <ul class="s-formation__phases" role="list">

        <li class="s-formation__phase">
          <div>
            <p class="s-formation__phase-label">Phase I</p>
            <p class="s-formation__phase-label" style="margin-top: 6px;">In progress</p>
          </div>
          <div>
            <h2 class="s-formation__phase-title">Doctrine</h2>
            <p class="s-formation__phase-body">
              The intellectual work that must be done before the first garment
              can be made. Stage definition. Material research. Clinical
              consultation. The construction protocols that will govern the house.
              This is the current phase. The work of this phase is visible here.
            </p>
          </div>
        </li>

        <li class="s-formation__phase">
          <div>
            <p class="s-formation__phase-label">Phase II</p>
            <p class="s-formation__phase-label" style="margin-top: 6px;">Forthcoming</p>
          </div>
          <div>
            <h2 class="s-formation__phase-title">Atelier</h2>
            <p class="s-formation__phase-body">
              Prototype construction. Material sourcing and testing against the
              stage requirements of Phase I. The establishment of the house's
              construction vocabulary: the seam treatments, the closure systems,
              the finishing standards that will define AVONTAÉ in every piece it makes.
            </p>
          </div>
        </li>

        <li class="s-formation__phase">
          <div>
            <p class="s-formation__phase-label">Phase III</p>
            <p class="s-formation__phase-label" style="margin-top: 6px;">In preparation</p>
          </div>
          <div>
            <h2 class="s-formation__phase-title">The House Opens</h2>
            <p class="s-formation__phase-body">
              A considered collection organised across six developmental stages.
              Available only through the house directly. No wholesale.
              No retail partnerships. Presented when the standard is met.
              Not before. Those who entered the Founding Circle will be the first to know.
            </p>
          </div>
        </li>

      </ul>
    </div>
  </section>

  <!-- DARK CLOSE: CTA to Founding Circle -->
  <section class="s-house reveal" aria-labelledby="about-cta-heading">
    <div class="s-house__inner">
      <p class="s-house__label">The House</p>
      <h2 class="s-house__heading" id="about-cta-heading">
        Not yet open.<br>
        Being built<br>
        <em>with full intention.</em>
      </h2>
      <p class="s-house__body">
        Those who wish to follow the formation of this house are invited
        to register with the Founding Circle. It is not a mailing list.
        It is a record of early understanding.
      </p>
      <p class="s-house__body">
        <a href="<?php echo esc_url( home_url( '/' ) ); ?>#founding-circle" style="color: var(--on-dark);
                  text-decoration: none;
                  border-bottom: 1px solid rgba(232,228,222,0.3);
                  padding-bottom: 3px;
                  letter-spacing: 0.08em;">
          Register with the Founding Circle
        </a>
      </p>
    </div>
  </section>

</main>

<?php
get_footer();