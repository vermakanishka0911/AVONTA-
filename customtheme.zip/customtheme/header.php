<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />

  <!-- SEO -->
  <meta name="description"
    content="AVONTAÉ is a luxury house dedicated to the first year of life. Organised around developmental stage, not size. French atelier standards. Currently in formation." />
  <meta name="keywords"
    content="luxury childrenswear, premature baby clothes, newborn luxury, developmental stages, French atelier standards, AVONTAÉ" />
  <meta name="robots" content="index, follow" />
  <meta name="theme-color" content="#F4F1EC" />
  <link rel="canonical" href="https://avontae.com/" />
  <link rel="icon" type="image/x-icon" href="favicon.ico" />

  <!-- Open Graph -->
  <meta property="og:type" content="website" />
  <meta property="og:url" content="https://avontae.com/" />
  <meta property="og:title" content="AVONTAÉ | Luxury Childrenswear for the First Year of Life" />
  <meta property="og:description"
    content="A luxury house being built around developmental stage, not size. French atelier standards for the most precious year of a child's life." />
  <meta property="og:image"
    content="https://images.pexels.com/photos/19550894/pexels-photo-19550894.jpeg?auto=compress&cs=tinysrgb&w=1200" />

  <!-- Twitter Card -->
  <meta name="twitter:card" content="summary_large_image" />
  <meta name="twitter:title" content="AVONTAÉ | Luxury Childrenswear" />
  <meta name="twitter:description"
    content="A luxury house dedicated to the first year of life. French atelier standards for the most precious year." />
  <meta name="twitter:image"
    content="https://images.pexels.com/photos/19550894/pexels-photo-19550894.jpeg?auto=compress&cs=tinysrgb&w=1200" />

  <!-- Structured Data -->
  <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "Organization",
    "name": "AVONTAÉ",
    "url": "https://avontae.com",
    "description": "A luxury childrenswear house organised around developmental stage for the first year of life. French atelier construction standards.",
    "foundingDate": "2024",
    "contactPoint": {
      "@type": "ContactPoint",
      "email": "contact@avontae.com",
      "contactType": "Customer Service"
    }
  }
  </script>

<?php
wp_head();
?>
</head>

<body>

  <a class="skip-nav" href="#main-content">Skip to main content</a>

  <!-- HEADER: logo on left; nav + cart + mobile trigger on the right -->
  <header class="site-header" id="siteHeader" role="banner" aria-label="Site header">
    <div class="site-header__inner">
      <!-- LOGO (PNG preferred; fallback to wordmark SVG) -->
      <div class="site-logo">
        <img src="assets/avontae-logo-2.png" alt="AVONTAÉ logo" id="headerLogo"
          onerror="this.style.display='none'; document.getElementById('logoFallback').style.display='block'" />
        <svg id="logoFallback" viewBox="0 0 196 30" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="AVONTAÉ"
          style="display:none;">
          <text x="0" y="22" font-family="'Cormorant Garamond', Georgia, serif" font-weight="400" font-size="18"
            letter-spacing="8" fill="currentColor">AVONTAÉ</text>
        </svg>
      </div>




      <!-- RIGHT: primary nav (desktop) + controls -->
      <div class="site-controls" role="group" aria-label="Header controls">
        <nav class="primary-nav" aria-label="Primary navigation">
          <a href="/" aria-current="page">House</a>
          <a href="about/">Foundation</a>
          <a href="contact/">Correspondence</a>
        </nav>

        <!-- Cart button (placeholder) -->
        <button id="cartButton" class="icon-button" aria-label="Open cart (0 items)" title="Open cart">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden>
            <path d="M6 2h12l-1.2 4H7.2L6 2Z" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"
              stroke-linejoin="round" />
            <path d="M6 6h12l-1 14H7L6 6Z" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"
              stroke-linejoin="round" />
            <path d="M9 10a3 3 0 0 1 6 0" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"
              stroke-linejoin="round" />
          </svg>
        </button>

        <!-- Mobile menu trigger -->
        <button id="menuToggle" class="nav-trigger" aria-label="Open menu" aria-expanded="false"
          aria-controls="mobileMenu">
          <span aria-hidden="true"></span>
          <span aria-hidden="true"></span>
          <span aria-hidden="true"></span>
        </button>
      </div>
    </div>
  </header>

  <!-- Mobile menu overlay -->
  <div id="mobileMenu" class="mobile-menu-overlay" role="dialog" aria-modal="true" aria-label="Mobile menu">
    <div class="mobile-menu" role="navigation" aria-label="Mobile primary">
      <a href="/">House</a>
      <a href="about/">Foundation</a>
      <a href="contact/">Correspondence</a>
    </div>
  </div>

  <!-- Cart panel (placeholder) -->
  <aside id="cartPanel" class="cart-panel" aria-hidden="true" aria-label="Shopping cart">
    <button id="closeCart" class="icon-button" aria-label="Close cart" style="float:right">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden>
        <path d="M18 6L6 18M6 6l12 12" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"
          stroke-linejoin="round" />
      </svg>
    </button>
    <h3 tabindex="-1">Your cart</h3>
    <p style="color:var(--body-mid);margin-top:12px;">Cart functionality is a placeholder. Wire this to your cart state
      or backend.</p>
  </aside>