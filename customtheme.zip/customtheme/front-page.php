
<?php
get_header();

?>
  <main id="main-content" style="margin-top:110px;">

    <!-- HERO -->
    <section class="s-hero" aria-label="AVONTAÉ: a luxury house for the first year of life">
      <img class="s-hero__image"
        src="https://images.pexels.com/photos/19550894/pexels-photo-19550894.jpeg?auto=compress&cs=tinysrgb&w=1800&fit=crop"
        alt="A mother holding her sleeping newborn with quiet tenderness"
        onerror="this.src='https://images.pexels.com/photos/325690/pexels-photo-325690.jpeg?auto=compress&cs=tinysrgb&w=1800&fit=crop'" />
      <div class="s-hero__veil" aria-hidden="true"></div>
      <div class="s-hero__content">
        <h1 class="t-display">
          Some children<br>
          arrive before<br>
          <em>the world is ready.</em>
        </h1>
      </div>
    </section>

    <!-- THE PREMISE -->
    <section class="s-premise reveal" aria-labelledby="premise-heading">
      <div class="s-premise__inner">
        <p class="t-eyebrow" id="premise-heading">The Premise</p>
        <p class="s-premise__statement">
          The first year of life moves through stages. Each one distinct.
          Each one placing its own demands on the body, on what it needs,
          on what should and should not touch the skin.
          No luxury house has ever been built around that truth.
          <em>AVONTAÉ is being built to change that.</em>
        </p>
      </div>
    </section>

    <!-- IMAGE PAUSE: Linen -->
    <div class="s-image-pause reveal" role="img"
      aria-label="Close study of linen weave. Material under consideration for AVONTAÉ.">
      <img
        src="https://images.pexels.com/photos/7794365/pexels-photo-7794365.jpeg?auto=compress&cs=tinysrgb&w=1800&fit=crop"
        alt="" aria-hidden="true"
        onerror="this.src='https://images.pexels.com/photos/7641149/pexels-photo-7641149.jpeg?auto=compress&cs=tinysrgb&w=1800&fit=crop'" />
      <p class="s-image-pause__caption" aria-hidden="true">Material Study. Linen. AVONTAÉ.</p>
    </div>

    <!-- THE STANDARD -->
    <section class="s-standard reveal" aria-labelledby="standard-heading">
      <div class="s-standard__grid">
        <div>
          <p class="t-eyebrow" id="standard-heading">The Standard</p>
          <div class="u-rule" style="margin-top: 2rem;" aria-hidden="true"></div>
        </div>
        <div>
          <ul class="s-standard__principles" role="list">
            <li>
              <span class="s-standard__index" aria-hidden="true">I</span>
              <span class="s-standard__text">
                <strong>Stage, Not Size</strong>
                Sizing tells you how large a child is. It tells you nothing about where they are.
                A premature baby and a full-term newborn of identical weight inhabit entirely
                different developmental realities. AVONTAÉ begins with that difference.
                Every piece begins with a stage. Not a measurement.
              </span>
            </li>
            <li>
              <span class="s-standard__index" aria-hidden="true">II</span>
              <span class="s-standard__text">
                <strong>French Atelier Standards</strong>
                The French tradition of construction holds that a garment is only finished
                when every decision has been made with complete intention. Seam placement.
                Cloth weight. The precise fall of fabric against skin. For a body this new,
                that level of care is not a stylistic choice. It is a duty.
              </span>
            </li>
            <li>
              <span class="s-standard__index" aria-hidden="true">III</span>
              <span class="s-standard__text">
                <strong>The Cloth Comes First</strong>
                Nothing in this house begins as a sketch. It begins as a question:
                what does this stage require? The cloth is chosen to answer that question.
                The cut follows. The fibre before the form, always.
              </span>
            </li>
            <li>
              <span class="s-standard__index" aria-hidden="true">IV</span>
              <span class="s-standard__text">
                <strong>Built to Last</strong>
                AVONTAÉ will not operate by season. What is made with genuine conviction
                does not require reinvention. The house opens when the standard is ready.
                Not before. This is the only timeline that matters to us.
              </span>
            </li>
          </ul>
        </div>
      </div>
    </section>

    <!-- IMAGE PAUSE: Quote -->
    <div class="s-image-pause s-image-pause--text reveal" role="img"
      aria-label="Adult hands cradling newborn feet. A study in scale and the weight of care.">
      <img
        src="https://images.pexels.com/photos/325690/pexels-photo-325690.jpeg?auto=compress&cs=tinysrgb&w=1800&fit=crop"
        alt="" aria-hidden="true"
        onerror="this.src='https://images.pexels.com/photos/9666398/pexels-photo-9666398.jpeg?auto=compress&cs=tinysrgb&w=1800&fit=crop'" />
      <div class="s-image-pause__overlay">
        <blockquote class="s-image-pause__quote">
          <p>The seam that rests against an infant's skin<br>
            is not a construction decision.<br>
            <em>It is a sensory one of the first order.</em>
          </p>
        </blockquote>
      </div>
    </div>

    <!-- THE JOURNAL -->
    <section class="s-journal reveal" aria-labelledby="journal-heading">
      <p class="t-eyebrow" id="journal-heading">The Journal</p>
      <div class="s-journal__entries">

        <article class="s-journal__entry">
          <div class="s-journal__image-wrap">
            <img
              src="https://images.pexels.com/photos/7218976/pexels-photo-7218976.jpeg?auto=compress&cs=tinysrgb&w=700&fit=crop"
              alt="Hands at work with needle and thread, the considered act of construction" loading="lazy"
              onerror="this.style.background='#E8E2D9';" />
          </div>
          <div class="s-journal__meta">
            <p class="s-journal__cat">Craft Doctrine</p>
            <h2 class="s-journal__title">On the Considered Stitch</h2>
            <p class="s-journal__excerpt">
              Every seam has a position relative to the body. The French atelier tradition
              holds that this position is never accidental. It is chosen. For skin as new
              and as sensitive as an infant's, that choice carries a weight that goes beyond
              craft. It is the first act of care built into the cloth.
            </p>
            <a class="s-journal__link" href="about.html">Read</a>
          </div>
        </article>

        <article class="s-journal__entry">
          <div class="s-journal__image-wrap">
            <img
              src="https://images.pexels.com/photos/9666398/pexels-photo-9666398.jpeg?auto=compress&cs=tinysrgb&w=700&fit=crop"
              alt="Newborn feet cradled gently in adult hands, illustrating the scale at which this house works"
              loading="lazy" onerror="this.style.background='#E8E2D9';" />
          </div>
          <div class="s-journal__meta">
            <p class="s-journal__cat">Material</p>
            <h2 class="s-journal__title">Why Size Is the Wrong Measure</h2>
            <p class="s-journal__excerpt">
              Two children of the same weight can be in entirely different places.
              One has not yet lifted its head. The other reaches for what it cannot quite touch.
              A single size serves neither of them properly. This is where the thinking
              of this house begins. And where the category has always stopped short.
            </p>
            <a class="s-journal__link" href="about.html">Read</a>
          </div>
        </article>

        <article class="s-journal__entry">
          <div class="s-journal__image-wrap">
            <img
              src="https://images.pexels.com/photos/208189/pexels-photo-208189.jpeg?auto=compress&cs=tinysrgb&w=700&fit=crop"
              alt="A newborn hand holding an adult finger, in grayscale. The scale of the first year." loading="lazy"
              onerror="this.style.background='#E8E2D9';" />
          </div>
          <div class="s-journal__meta">
            <p class="s-journal__cat">Tradition</p>
            <h2 class="s-journal__title">What the French Atelier Understood</h2>
            <p class="s-journal__excerpt">
              The oldest luxury traditions knew that dressing an infant requires a
              wholly different kind of thought. Not a reduced adult standard.
              A completely reconsidered approach to a body at its most particular
              and its most precious stage. AVONTAÉ is being built within that understanding.
            </p>
            <a class="s-journal__link" href="about.html">Read</a>
          </div>
        </article>

      </div>
    </section>

    <!-- THE HOUSE -->
    <section class="s-house" aria-labelledby="house-heading">
      <div class="s-house__inner reveal">
        <p class="s-house__label">The House</p>
        <h2 class="s-house__heading" id="house-heading">
          Some things<br>
          cannot be rushed.<br>
          <em>This is one of them.</em>
        </h2>
        <p class="s-house__body">
          Nothing has been made yet. Not because the work is slow.
          Because the foundation must come before everything else.
          AVONTAÉ is being built from its values outward.
          When the house opens, everything in it will have been worth the wait.
        </p>
        <p class="s-house__body">
          The luxury childrenswear industry has not yet built a house
          organised around how a child actually develops in their first year.
          We are building that house. Carefully. With the rigour it has always deserved.
        </p>
      </div>
    </section>

    <!-- FOUNDING CIRCLE -->
    <section class="s-circle" id="founding-circle" aria-labelledby="circle-heading">
      <div class="s-circle__inner">

        <div class="s-circle__left reveal">
          <p class="s-circle__label">The Founding Circle</p>
          <h2 class="s-circle__heading" id="circle-heading">
            A private<br>
            <em>register.</em>
          </h2>
          <p class="s-circle__body">
            This is not a list you join. It is a record you enter.
            The Founding Circle holds the names of those who understood
            before anything existed to understand.
          </p>
          <p class="s-circle__body">
            Members receive The Journal and occasional correspondence
            from within the formation of the house. Nothing more is offered,
            because nothing more is ready.
          </p>
          <p class="s-circle__body" style="font-size: 0.8rem; opacity: 0.7; margin-top: 1.5rem;">
            There is no urgency here. No offer. Only the question of whether
            what this house is building matters to you. If it does,
            the register is open. It will not always be.
          </p>
        </div>

        <div class="reveal">
          <form class="s-circle__form" id="circleForm" novalidate
            action="https://formspree.io/f/REPLACE_WITH_YOUR_FORMSPREE_ID" method="POST"
            aria-label="Founding Circle registration form">
            <div class="form-field">
              <label class="form-label" for="c-name">Full Name</label>
              <input class="form-input s-circle__input" id="c-name" name="name" type="text" required
                aria-required="true" autocomplete="name" placeholder="Your name" />
            </div>
            <div class="form-field">
              <label class="form-label" for="c-email">Email Address</label>
              <input class="form-input s-circle__input" id="c-email" name="email" type="email" required
                aria-required="true" autocomplete="email" placeholder="your@email.com" />
            </div>
            <div class="form-field">
              <label class="form-label" for="c-context">
                Context
                <em
                  style="font-style: italic; text-transform: none; letter-spacing: 0; opacity: 0.5; font-size: 0.8em;">optional</em>
              </label>
              <input class="form-input s-circle__input" id="c-context" name="context" type="text" autocomplete="off"
                placeholder="How you came to find us" />
            </div>
            <button class="form-submit" type="submit" id="circleSubmit">
              Enter the register
            </button>
            <p class="form-confirm" id="c-confirm" role="status" aria-live="polite" hidden>
              Your entry has been recorded. We will be in correspondence.
            </p>
            <p class="s-circle__note" style="margin-top: 2.5rem;">
              Entries are reviewed. We do not share, sell, or leverage your information.
            </p>
          </form>
        </div>

      </div>
    </section>

  </main>

  <?php

  get_footer();
  ?>
 