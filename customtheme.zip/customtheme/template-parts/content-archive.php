<?php
/**
 * template-parts/content-archive.php
 *
 * Post item used by your index/archive loop.
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class('post'); ?>>

  <div class="container-inner">
    <div class="media-row">

      <div class="media-body">
        <h3 class="title">
          <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
        </h3>

        <div class="meta">
          <span class="date"><?php echo esc_html( get_the_date() ); ?></span>
          <span class="comments"> &middot; <a href="<?php the_permalink(); ?>#comments"><?php comments_number( '0', '1', '%' ); ?></a></span>
        </div>

        <div class="intro">
          <?php
          if ( has_excerpt() ) {
            the_excerpt();
          } else {
            echo wp_kses_post( wp_trim_words( get_the_content(), 35, '...' ) );
          }
          ?>
        </div>

        <a class="more-link" href="<?php the_permalink(); ?>">Read more &rarr;</a>
      </div><!-- .media-body -->

      <?php
      // Thumbnail (fallback to placeholder)
      if ( has_post_thumbnail() ) {
        $thumb_url = esc_url( get_the_post_thumbnail_url( get_the_ID(), 'archive-thumb' ) );
      } else {
        // put a placeholder image at /wp-content/themes/your-theme/images/placeholder-320x240.png
        $thumb_url = esc_url( get_template_directory_uri() . '/images/placeholder-320x240.png' );
      }
      ?>
      <figure class="post-thumb" aria-hidden="true">
        <a href="<?php the_permalink(); ?>">
          <img src="<?php echo $thumb_url; ?>" alt="<?php echo esc_attr( get_the_title() ); ?>" />
        </a>
      </figure>

    </div><!-- .media-row -->
  </div><!-- .container-inner -->

</article>