<?php
/**
 * template-parts/content-blog.php
 * Clean, minimal UI for single post + archive fallback.
 *
 * Usage:
 *   get_template_part( 'template-parts/content', 'blog' );
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class( 's-article' ); ?>>

  <?php if ( is_singular() ) : // Single post view -------------------------------------------------- ?>

    <!-- HERO (featured image as large visual) -->
    <header class="s-article__hero s-hero" role="banner" aria-label="<?php the_title_attribute(); ?>">
      <?php if ( has_post_thumbnail() ) : ?>
        <?php the_post_thumbnail( 'avontae-hero', array(
          'class' => 's-hero__image',
          'alt'   => the_title_attribute( array( 'echo' => false ) ),
          'loading' => 'eager',
        ) ); ?>
      <?php else : ?>
        <img class="s-hero__image" src="<?php echo esc_url( get_template_directory_uri() . '/assets/default-hero.jpg' ); ?>" alt="<?php echo esc_attr( get_the_title() ); ?>" loading="eager" />
      <?php endif; ?>

      <div class="s-hero__veil" aria-hidden="true"></div>

      <div class="s-hero__content">
        <?php
          // Eyebrow: first category (if present)
          $cats = get_the_category();
          if ( ! empty( $cats ) ) :
        ?>
          <div class="s-hero__eyebrow t-eyebrow"><?php echo esc_html( $cats[0]->name ); ?></div>
        <?php endif; ?>

        <h1 class="t-display s-article__title"><?php the_title(); ?></h1>

        <div class="s-article__meta t-body">
          <time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time>
          <span class="s-article__meta-sep" aria-hidden="true"> — </span>
          <span class="s-article__author"><?php the_author(); ?></span>
        </div>
      </div>
    </header>

    <!-- CONTENT -->
    <div class="s-article__body u-container--narrow">
      <div class="entry-content t-body">
        <?php
          the_content();
          wp_link_pages( array(
            'before' => '<nav class="page-links" aria-label="' . esc_attr__( 'Pages', 'avontae' ) . '">',
            'after'  => '</nav>',
          ) );
        ?>
      </div>

      <!-- TAGS -->
      <?php if ( has_tag() ) : ?>
        <footer class="post-meta">
          <div class="post-tags">
            <span class="t-eyebrow">Tags</span>
            <div class="post-tags__list">
              <?php the_tags( '', ' ', '' ); ?>
            </div>
          </div>
        </footer>
      <?php endif; ?>

      <!-- EDIT LINK -->
      <div class="post-edit-link">
        <?php edit_post_link( __( 'Edit', 'avontae' ), '<span class="edit-link">', '</span>' ); ?>
      </div>

      <!-- COMMENTS -->
      <?php
        if ( comments_open() || get_comments_number() ) {
          echo '<section class="post-comments" aria-label="' . esc_attr__( 'Comments', 'avontae' ) . '">';
          comments_template();
          echo '</section>';
        }
      ?>
    </div>

  <?php else : // Archive / index view -------------------------------------------------------------- ?>

    <div class="post-card u-container--narrow">
      <a class="post-card__link" href="<?php the_permalink(); ?>">
        <?php if ( has_post_thumbnail() ) : ?>
          <div class="post-card__media">
            <?php the_post_thumbnail( 'avontae-thumb', array( 'alt' => the_title_attribute( array( 'echo' => false ) ), 'loading' => 'lazy' ) ); ?>
          </div>
        <?php endif; ?>

        <div class="post-card__body">
          <h2 class="post-card__title"><?php the_title(); ?></h2>
          <div class="post-card__meta t-body">
            <time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time>
            <?php if ( has_category() ) : ?>
              <span class="post-card__cat"> · <?php the_category( ', ' ); ?></span>
            <?php endif; ?>
          </div>

          <div class="post-card__excerpt entry-summary t-body">
            <?php the_excerpt(); ?>
          </div>
        </div>
      </a>
    </div>

  <?php endif; ?>
</article>