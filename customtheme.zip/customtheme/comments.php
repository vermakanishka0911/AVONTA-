<?php
/**
 * comments.php
 * Comment list + form for AvontaeTheme
 *
 * Place this file in your theme root.
 */

// Exit early when post is password protected
if ( post_password_required() ) {
  return;
}

/**
 * Custom comment markup callback
 */
function avontae_comment( $comment, $args, $depth ) {
  $tag = ( 'div' === $args['style'] ) ? 'div' : 'li';
  ?>
  <<?php echo $tag ?> id="comment-<?php comment_ID(); ?>" <?php comment_class( 'comment' ); ?>>
    <article id="div-comment-<?php comment_ID(); ?>" class="comment-body u-container--narrow">
      <div class="comment-inner" style="display:grid;grid-template-columns:64px 1fr;gap:16px;align-items:start;">
        <div class="comment-avatar">
          <?php
            echo get_avatar( $comment, 56, '', get_comment_author( $comment ) );
          ?>
        </div>

        <div class="comment-main">
          <header class="comment-meta">
            <span class="comment-author">
              <?php
                printf(
                  '<span class="fn">%s</span>',
                  get_comment_author_link( $comment )
                );
              ?>
            </span>
            <span class="comment-date"> — <a href="<?php echo esc_url( get_comment_link( $comment->comment_ID ) ); ?>">
              <time datetime="<?php comment_time( 'c' ); ?>"><?php printf( '%1$s', get_comment_date( '', $comment ) ); ?></time>
            </a></span>

            <?php
              // edit link for users who can edit
              edit_comment_link( esc_html__( 'Edit', 'avontae' ), '<span class="comment-edit">', '</span>' );
            ?>
          </header>

          <div class="comment-content">
            <?php if ( '0' == $comment->comment_approved ) : ?>
              <p class="comment-awaiting-moderation"><?php esc_html_e( 'Your comment is awaiting moderation.', 'avontae' ); ?></p>
            <?php endif; ?>
            <?php comment_text(); ?>
          </div>

          <div class="comment-actions" style="margin-top:8px;">
            <?php
              // reply link (respects $depth and max_depth)
              comment_reply_link( array_merge( $args, array(
                'reply_text' => esc_html__( 'Reply', 'avontae' ),
                'depth'      => $depth,
                'max_depth'  => $args['max_depth'],
                'before'     => '<span class="comment-reply-link">',
                'after'      => '</span>',
              ) ), $comment );
            ?>
          </div>
        </div>
      </div>
    </article>
  <?php
  if ( 'li' !== $tag ) {
    // nothing
  }
}

?>

<div id="comments" class="comments-area u-container--narrow">

  <?php if ( have_comments() ) : ?>
    <h3 class="comments-title t-heading">
      <?php
        $count = get_comments_number();
        if ( 1 === $count ) {
          printf( esc_html__( '1 Comment', 'avontae' ) );
        } else {
          printf( esc_html( _n( '%s Comment', '%s Comments', $count, 'avontae' ) ), number_format_i18n( $count ) );
        }
      ?>
    </h3>

    <?php if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) : ?>
      <nav class="comment-navigation" role="navigation" aria-label="<?php esc_attr_e( 'Comment Navigation', 'avontae' ); ?>">
        <div class="nav-previous"><?php previous_comments_link( esc_html__( 'Older Comments', 'avontae' ) ); ?></div>
        <div class="nav-next"><?php next_comments_link( esc_html__( 'Newer Comments', 'avontae' ) ); ?></div>
      </nav>
    <?php endif; ?>

    <ol class="comment-list">
      <?php
        wp_list_comments( array(
          'style'      => 'ol',
          'short_ping' => true,
          'avatar_size'=> 56,
          'callback'   => 'avontae_comment',
        ) );
      ?>
    </ol>

    <?php if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) : ?>
      <nav class="comment-navigation comment-navigation-bottom" role="navigation" aria-label="<?php esc_attr_e( 'Comment Navigation', 'avontae' ); ?>">
        <div class="nav-previous"><?php previous_comments_link( esc_html__( 'Older Comments', 'avontae' ) ); ?></div>
        <div class="nav-next"><?php next_comments_link( esc_html__( 'Newer Comments', 'avontae' ) ); ?></div>
      </nav>
    <?php endif; ?>

  <?php endif; // have_comments() ?>

  <?php
    // Comment form args (styled to match theme classes/tokens)
    $commenter = wp_get_current_commenter();
    $req = get_option( 'require_name_email' );
    $aria_req = ( $req ? " aria-required='true' required" : '' );

    $form_args = array(
      'class_form'         => 'comment-form',
      'id_form'            => 'commentform',
      'title_reply'        => esc_html__( 'Leave a reply', 'avontae' ),
      'title_reply_before' => '<h3 id="reply-title" class="t-heading comment-reply-title">',
      'title_reply_after'  => '</h3>',
      'comment_field'      => '<p class="comment-form-comment"><label for="comment" class="sr-only">' . esc_html__( 'Comment', 'avontae' ) . '</label><textarea id="comment" name="comment" class="form-textarea" placeholder="' . esc_attr__( 'Write your comment…', 'avontae' ) . '" rows="6" required></textarea></p>',
      'fields'             => array(
        'author' => '<p class="comment-form-author"><label for="author" class="sr-only">' . esc_html__( 'Name', 'avontae' ) . '</label><input id="author" name="author" class="form-input" type="text" value="' . esc_attr( $commenter['comment_author'] ) . '" placeholder="' . esc_attr__( 'Your name', 'avontae' ) . '"' . $aria_req . ' /></p>',
        'email'  => '<p class="comment-form-email"><label for="email" class="sr-only">' . esc_html__( 'Email', 'avontae' ) . '</label><input id="email" name="email" class="form-input" type="email" value="' . esc_attr( $commenter['comment_author_email'] ) . '" placeholder="' . esc_attr__( 'Your email', 'avontae' ) . '"' . $aria_req . ' /></p>',
        'url'    => '<p class="comment-form-url"><label for="url" class="sr-only">' . esc_html__( 'Website', 'avontae' ) . '</label><input id="url" name="url" class="form-input" type="url" value="' . esc_attr( $commenter['comment_author_url'] ) . '" placeholder="' . esc_attr__( 'Website (optional)', 'avontae' ) . '" /></p>',
      ),
      'label_submit'       => esc_html__( 'Post comment', 'avontae' ),
      'submit_field'       => '<p class="form-submit">%1$s %2$s</p>',
      'class_submit'       => 'form-submit',
      'logged_in_as'       => '<p class="logged-in-as t-body">' . sprintf( wp_kses_post( __( 'Logged in as <a href="%1$s">%2$s</a>.', 'avontae' ) ), get_edit_user_link(), wp_get_current_user()->display_name ) . '</p>',
      'comment_notes_before' => '',
      'comment_notes_after'  => '',
    );

    comment_form( $form_args );
  ?>

</div><!-- #comments -->