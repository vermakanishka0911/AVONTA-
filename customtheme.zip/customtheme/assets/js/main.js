
    (function () {
      // Header / mobile menu / cart behavior
      const header = document.getElementById('siteHeader');
      const menuToggle = document.getElementById('menuToggle');
      const mobileMenu = document.getElementById('mobileMenu');
      const cartBtn = document.getElementById('cartButton');
      const cartPanel = document.getElementById('cartPanel');
      const closeCart = document.getElementById('closeCart');

      function onScroll() {
        const scrolled = window.scrollY > 60;
        header.classList.toggle('nav--scrolled', scrolled);
      }
      window.addEventListener('scroll', onScroll, { passive: true });
      onScroll();

      // Mobile menu toggle
      function openMobile() {
        mobileMenu.classList.add('open');
        menuToggle.classList.add('open');
        menuToggle.setAttribute('aria-expanded', 'true');
        document.body.style.overflow = 'hidden';
        const first = mobileMenu.querySelector('a');
        if (first) first.focus();
      }
      function closeMobile() {
        mobileMenu.classList.remove('open');
        menuToggle.classList.remove('open');
        menuToggle.setAttribute('aria-expanded', 'false');
        document.body.style.overflow = '';
        menuToggle.focus();
      }
      menuToggle.addEventListener('click', () => {
        if (mobileMenu.classList.contains('open')) closeMobile(); else openMobile();
      });
      mobileMenu.addEventListener('click', (e) => {
        if (e.target === mobileMenu) closeMobile();
      });

      // cart panel
      function openCart() {
        cartPanel.classList.add('open');
        cartPanel.setAttribute('aria-hidden', 'false');
        document.body.style.overflow = 'hidden';
        if (mobileMenu.classList.contains('open')) closeMobile();
        const h3 = cartPanel.querySelector('h3');
        if (h3) h3.focus();
      }
      function closeCartPanel() {
        cartPanel.classList.remove('open');
        cartPanel.setAttribute('aria-hidden', 'true');
        document.body.style.overflow = '';
        cartBtn.focus();
      }
      cartBtn.addEventListener('click', openCart);
      closeCart.addEventListener('click', closeCartPanel);

      // Escape closes overlays
      document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
          if (mobileMenu.classList.contains('open')) closeMobile();
          if (cartPanel.classList.contains('open')) closeCartPanel();
        }
      });

      // Smooth scroll for internal anchors
      document.querySelectorAll('a[href^="#"]').forEach(a => {
        a.addEventListener('click', function (ev) {
          const href = this.getAttribute('href');
          if (!href || href === '#') return;
          const target = document.querySelector(href);
          if (target) {
            ev.preventDefault();
            target.scrollIntoView({ behavior: 'smooth' });
            if (mobileMenu.classList.contains('open')) closeMobile();
          }
        });
      });

      // IntersectionObserver for reveal items
      const obs = new IntersectionObserver(entries => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.classList.add('in-view');
            obs.unobserve(entry.target);
          }
        });
      }, { threshold: 0.08 });
      document.querySelectorAll('.reveal').forEach(el => obs.observe(el));

      // Footer year
      document.getElementById('currentYear').textContent = new Date().getFullYear();

      // Defensive state reset
      mobileMenu.classList.remove('open');
      cartPanel.classList.remove('open');
      menuToggle.setAttribute('aria-expanded', 'false');
      cartPanel.setAttribute('aria-hidden', 'true');
    })();



    