<?php
/**
 * Template Name: Contact (Correspondence)
 *
 * page-contact.php
 *
 * Use this template for the Contact / Correspondence page.
 */

get_header();
?>

<?php
while ( have_posts() ) :
  the_post();
  // If you want the page content from the editor above/below the custom layout,
  // you can uncomment the line below:
  // the_content();
endwhile;
?>

<main id="main-content" style="margin-top:110px;">

  <!-- HERO -->
  <section class="s-hero" aria-label="Correspondence with AVONTAÉ">
    <img class="s-hero__image"
      src="https://images.pexels.com/photos/7641149/pexels-photo-7641149.jpeg?auto=compress&cs=tinysrgb&w=1800&fit=crop"
      alt="Close detail of beige linen cloth, its weave precise and calm"
      onerror="this.src='https://images.pexels.com/photos/7794365/pexels-photo-7794365.jpeg?auto=compress&cs=tinysrgb&w=1800&fit=crop'" />
    <div class="s-hero__veil" aria-hidden="true"></div>
    <div class="s-hero__content">
      <h1 class="t-display">
        The house<br>
        receives<br>
        <em>correspondence.</em>
      </h1>
    </div>
  </section>

  <!-- THE PREMISE -->
  <section class="s-premise reveal" aria-labelledby="contact-premise-heading">
    <div class="s-premise__inner">
      <p class="t-eyebrow" id="contact-premise-heading">On Correspondence</p>
      <p class="s-premise__statement">
        AVONTAÉ is in formation. There are no products yet.
        No collections. No samples to preview.
        What exists is the doctrine, the standard, and the question
        of whether this house will matter to you when it opens.
        <em>Enquiries of substance are welcomed.</em>
      </p>
    </div>
  </section>

  <!-- CONTACT GRID: Form + Channels -->
  <div class="s-contact-grid reveal">

    <div>
      <p class="s-contact-form-heading">Write to the house</p>
      <form id="contactForm" action="https://formspree.io/f/REPLACE_WITH_YOUR_FORMSPREE_ID" method="POST" novalidate
        aria-label="Contact form for AVONTAÉ">

        <div class="form-field">
          <label class="form-label" for="contact-name">Your name</label>
          <input class="form-input" type="text" id="contact-name" name="name" autocomplete="name" aria-required="true"
            placeholder="Full name" />
        </div>

        <div class="form-field">
          <label class="form-label" for="contact-email">Email address</label>
          <input class="form-input" type="email" id="contact-email" name="email" autocomplete="email"
            aria-required="true" placeholder="your@email.com" />
        </div>

        <div class="form-field">
          <label class="form-label" for="contact-nature">Nature of your enquiry</label>
          <select class="form-select" id="contact-nature" name="nature" aria-required="true">
            <option value="" disabled selected>Please select</option>
            <option value="doctrine">The doctrine</option>
            <option value="collaboration">Collaboration</option>
            <option value="institutional">Institutional interest</option>
            <option value="press">Press and editorial</option>
            <option value="founding">The Founding Circle</option>
            <option value="other">Other</option>
          </select>
        </div>

        <div class="form-field">
          <label class="form-label" for="contact-message">Your message</label>
          <textarea class="form-textarea" id="contact-message" name="message" rows="5" aria-required="true"
            placeholder="We welcome correspondence of substance"></textarea>
        </div>

        <button class="form-submit" type="submit" id="contactSubmit">
          Send correspondence
        </button>

        <div class="form-confirm" id="contactConfirm" role="status" aria-live="polite" hidden>
          Your message has been received. The house responds to correspondence of substance.
        </div>

      </form>
    </div>

    <div>
      <p class="s-contact-form-heading">Direct channels</p>
      <ul class="s-contact-channels" role="list">

        <li class="s-contact-channel">
          <p class="s-contact-channel__label">General Correspondence</p>
          <a href="/cdn-cgi/l/email-protection#c3a0acadb7a2a0b783a2b5acadb7a2a6eda0acae"
            class="s-contact-channel__value">
            <span class="__cf_email__"
              data-cfemail="dcbfb3b2a8bdbfa89cbdaab3b2a8bdb9f2bfb3b1">[email&#160;protected]</span>
          </a>
          <p class="s-contact-channel__note">
            For all written enquiries. The house reads every message
            and responds to those with genuine interest in the work.
          </p>
        </li>

        <li class="s-contact-channel">
          <p class="s-contact-channel__label">Press and Institutional</p>
          <a href="/cdn-cgi/l/email-protection#9ffcf0f1ebfefcebdffee9f0f1ebfefab1fcf0f2"
            class="s-contact-channel__value">
            <span class="__cf_email__"
              data-cfemail="04676b6a706567704465726b6a7065612a676b69">[email&#160;protected]</span>
          </a>
          <p class="s-contact-channel__note">
            Editorial interest, institutional enquiries, and conversations
            about the formation of this house are welcome here.
          </p>
        </li>

        <li class="s-contact-channel">
          <p class="s-contact-channel__label">A note on response times</p>
          <p class="s-contact-channel__value" style="cursor: default; text-decoration: none;">
            Considered, not immediate
          </p>
          <p class="s-contact-channel__note">
            AVONTAÉ is a house in formation. We are not structured
            for rapid response. Every enquiry of substance receives
            a reply that reflects the care it deserves.
          </p>
        </li>

      </ul>
    </div>

  </div>

  <!-- FOUNDING CIRCLE CTA -->
  <section class="s-house reveal" aria-labelledby="contact-circle-heading">
    <div class="s-house__inner">
      <p class="s-house__label">The Founding Circle</p>
      <h2 class="s-house__heading" id="contact-circle-heading">
        Those who understand<br>
        before the house exists<br>
        <em>are the ones we remember.</em>
      </h2>
      <p class="s-house__body">
        The Founding Circle is a private register. Not a mailing list.
        A record of early and considered interest in what this house is building.
        Members receive The Journal and correspondence from within
        the formation process. Nothing more is offered,
        because nothing more is ready.
      </p>
      <p class="s-house__body">
        <a href="<?php echo esc_url( home_url( '/' ) ); ?>#founding-circle" style="color: var(--on-dark);
                  text-decoration: none;
                  border-bottom: 1px solid rgba(232,228,222,0.3);
                  padding-bottom: 3px;
                  letter-spacing: 0.08em;">
          Enter the Founding Circle
        </a>
      </p>
    </div>
  </section>

</main>

<?php
get_footer();