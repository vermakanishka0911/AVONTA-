<?php
/**
 * Theme functions for AvontaeTheme
 */

/**
 * Register theme menus
 */
function avontae_register_menus() {
    register_nav_menus( array(
        'primary' => __( 'Primary Menu', 'avontae' ),
        'footer'  => __( 'Footer Menu', 'avontae' ),
    ) );
}
add_action( 'init', 'avontae_register_menus' );

/**
 * Theme setup: supports, image sizes, etc.
 */
function avontae_setup() {
    // let WP manage the document title
    add_theme_support( 'title-tag' );

    // featured images (post thumbnails)
    add_theme_support( 'post-thumbnails' );

    // custom logo support
    add_theme_support( 'custom-logo', array(
        'height'      => 36,
        'width'       => 220,
        'flex-height' => true,
        'flex-width'  => true,
    ) );

    // image sizes
    add_image_size( 'avontae-hero', 1600, 900, true ); // cropped
    add_image_size( 'avontae-thumb', 400, 300, true );
    add_image_size( 'archive-thumb', 220, 150, true );
}
add_action( 'after_setup_theme', 'avontae_setup' );

/**
 * Utility: safe filemtime version helper
 */
function avontae_asset_version( $filepath ) {
    $full = get_stylesheet_directory() . '/' . ltrim( $filepath, '/' );
    if ( file_exists( $full ) ) {
        return filemtime( $full );
    }
    return null;
}

/**
 * Enqueue styles and scripts
 */
function avontae_enqueue_assets() {
    // Main theme stylesheet (style.css in theme root)
    $style_path = 'style.css';
    $style_ver  = avontae_asset_version( $style_path );
    wp_enqueue_style(
        'avontae-style',
        get_stylesheet_uri(),
        array(),
        $style_ver
    );

    // Google Fonts (single enqueue)
    $google_fonts_url = 'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&family=Cormorant+Garamond:wght@300;400;600&family=Libre+Baskerville:wght@400;700&display=swap';
    wp_enqueue_style(
        'avontae-google-fonts',
        esc_url_raw( $google_fonts_url ),
        array(),
        null
    );

    // Conditional: content-archive stylesheet only on posts index or archive pages
    $archive_css_path = 'assets/css/content-archive.css';
    if ( is_home() || is_archive() || is_post_type_archive( 'post' ) ) {
        $archive_ver = avontae_asset_version( $archive_css_path );
        wp_enqueue_style(
            'avontae-archive-style',
            get_stylesheet_directory_uri() . '/' . $archive_css_path,
            array( 'avontae-style' ),
            $archive_ver
        );
    }

    // Main JS (loaded in footer). Use filemtime for version while in development.
    $js_path = 'assets/js/main.js';
    $js_ver  = avontae_asset_version( $js_path ) ?: '1.0';
    wp_enqueue_script(
        'avontae-main',
        get_stylesheet_directory_uri() . '/' . $js_path,
        array(),    // dependencies (e.g. array('jquery')) if needed
        $js_ver,
        true        // load in footer
    );
}
add_action( 'wp_enqueue_scripts', 'avontae_enqueue_assets' );

/**
 * Add resource hints (preconnect) for Google Fonts when the fonts stylesheet is enqueued.
 * This is a cleaner alternative to echoing raw <link> tags in wp_head.
 */
function avontae_resource_hints( $urls, $relation_type ) {
    if ( 'preconnect' === $relation_type ) {
        // Only add if Google Fonts is enqueued
        if ( wp_style_is( 'avontae-google-fonts', 'enqueued' ) ) {
            $urls[] = 'https://fonts.googleapis.com';
            $urls[] = 'https://fonts.gstatic.com';
        }
    }
    return $urls;
}
add_filter( 'wp_resource_hints', 'avontae_resource_hints', 10, 2 );