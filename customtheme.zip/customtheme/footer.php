<footer class="site-footer" role="contentinfo">
    <div class="footer-inner">
        <div class="footer-top">
            <!-- Logo & Philosophy -->
            <div class="footer-column">
                <div class="footer-logo-wrap">
                    <img src="assets/avontae-logo-2.png" alt="AVONTAÉ" class="footer-logo"
                        onerror="this.style.display='none'; document.getElementById('footerFallback').style.display='block';" />
                    <span id="footerFallback" class="footer-logo-text" style="display:none;">AVONTAÉ</span>
                </div>
                <p class="footer-desc">A care-led institution for the earliest arrivals. Calm before commerce.</p>
            </div>

            <!-- Contact -->
            <div class="footer-column">
                <h4>Contact</h4>
                <div>
                    <p>care@avontae.com</p>
                    <p>+1 (888) 000-0000</p>
                </div>
            </div>

            <!-- Legal -->
            <div class="footer-column">
                <h4>Legal</h4>
                <div>
                    <a href="#" aria-label="Privacy Policy">Privacy Policy</a>
                    <a href="#" aria-label="Terms of Service">Terms of Service</a>
                    <a href="#" aria-label="Shipping and Returns">Shipping &amp; Returns</a>
                </div>
            </div>

            <div class="footer-column">
                <h4>Blogs</h4>
                <div>
                    <a href="/blog" aria-label="Privacy Policy">All Blog</a>
                    <a href="/first-post" aria-label="Privacy Policy">First Chapter</a>
                </div>
            </div>

        </div>


        <div class="footer-bottom" id="footerBottom">
            © <span id="currentYear"></span> AVONTAÉ. All rights reserved.
        </div>
    </div>
</footer>

<?php
wp_footer();
?>

</body>

</html>